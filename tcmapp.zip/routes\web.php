<?php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// PAGE 01: HOME
Route::get('/', function () {
    return Inertia::render('welcome');
})->name('home');

// PAGE 02: PRODUCTS
Route::get('/products', function () {
    return Inertia::render('products/index');
})->name('products');

// PAGE 03: PROFIL
Route::get('/profil', function () {
    return Inertia::render('profil/index');
})->name('profil');

// PAGE 04: LAYANAN
Route::get('/layanan', function () {
    return Inertia::render('layanan/index');
})->name('layanan');

// PAGE 05: KONTAK
Route::get('/kontak', function () {
    return Inertia::render('kontak/index');
})->name('kontak');
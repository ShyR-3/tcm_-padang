import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../wayfinder'
/**
 * @see routes/web.php:13
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:13
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:13
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:13
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:13
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:13
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:13
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
 * @see routes/web.php:18
 * @route '/products'
 */
export const products = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: products.url(options),
    method: 'get',
})

products.definition = {
    methods: ["get","head"],
    url: '/products',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:18
 * @route '/products'
 */
products.url = (options?: RouteQueryOptions) => {
    return products.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:18
 * @route '/products'
 */
products.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: products.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:18
 * @route '/products'
 */
products.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: products.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:18
 * @route '/products'
 */
    const productsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: products.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:18
 * @route '/products'
 */
        productsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: products.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:18
 * @route '/products'
 */
        productsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: products.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    products.form = productsForm
/**
 * @see routes/web.php:23
 * @route '/profil'
 */
export const profil = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profil.url(options),
    method: 'get',
})

profil.definition = {
    methods: ["get","head"],
    url: '/profil',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:23
 * @route '/profil'
 */
profil.url = (options?: RouteQueryOptions) => {
    return profil.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:23
 * @route '/profil'
 */
profil.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profil.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:23
 * @route '/profil'
 */
profil.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profil.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:23
 * @route '/profil'
 */
    const profilForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: profil.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:23
 * @route '/profil'
 */
        profilForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profil.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:23
 * @route '/profil'
 */
        profilForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profil.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    profil.form = profilForm
/**
 * @see routes/web.php:28
 * @route '/layanan'
 */
export const layanan = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: layanan.url(options),
    method: 'get',
})

layanan.definition = {
    methods: ["get","head"],
    url: '/layanan',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:28
 * @route '/layanan'
 */
layanan.url = (options?: RouteQueryOptions) => {
    return layanan.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:28
 * @route '/layanan'
 */
layanan.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: layanan.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:28
 * @route '/layanan'
 */
layanan.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: layanan.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:28
 * @route '/layanan'
 */
    const layananForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: layanan.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:28
 * @route '/layanan'
 */
        layananForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: layanan.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:28
 * @route '/layanan'
 */
        layananForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: layanan.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    layanan.form = layananForm
/**
 * @see routes/web.php:33
 * @route '/kontak'
 */
export const kontak = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kontak.url(options),
    method: 'get',
})

kontak.definition = {
    methods: ["get","head"],
    url: '/kontak',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:33
 * @route '/kontak'
 */
kontak.url = (options?: RouteQueryOptions) => {
    return kontak.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:33
 * @route '/kontak'
 */
kontak.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kontak.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:33
 * @route '/kontak'
 */
kontak.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: kontak.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:33
 * @route '/kontak'
 */
    const kontakForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: kontak.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:33
 * @route '/kontak'
 */
        kontakForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: kontak.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:33
 * @route '/kontak'
 */
        kontakForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: kontak.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    kontak.form = kontakForm